/**
    Copyright 2014-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.

    Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with the License. A copy of the License is located at

        http://aws.amazon.com/apache2.0/

    or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.
*/

module.exports = {
    "the lords prayer": "Our Father, who art in heaven. Hallowed be Thy Name, Thy kingdom come, thy will be done, On earth as it is in heaven. Give us this day our daily bread. And forgive us our debts, as we also have forgiven our debtors. And leave us not in temptation, but deliver us from evil, for thine is the kingdom, and the power, and the glory. forever. amen.",
    "the prayer of faith": "Any type of carpet can be crafted by placing two wool, of the same color, next to each other in a crafting window.",
    "achievement": "Flint is randomly dropped while breaking gravel.",
    "childbirth": "Any type of stained glass pane can be crafted by placing the same color stained glass, horizontally, in the bottom two rows."
};
