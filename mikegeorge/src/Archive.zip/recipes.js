/**
    Copyright 2014-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.

    Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with the License. A copy of the License is located at

        http://aws.amazon.com/apache2.0/

    or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.
*/

module.exports = {
    "favorite drink": "Mike George likes Cappuccino or Tequila. It depends on the time of day.",
    "weekend": "Mike George enjoys Chopping wood and be one with nature.",
    "favorite football team": "His favorite team is the Seattle Seahawks",
    "television show": "Mike George was on the Vikings",
    "grow up": "Mike George grew up in Balitmore Maryland.",
    "music": "He enjoys funky tunes like those from Bruno Mars and Meghan Traynor",
    "what should I do": "When you see Mike George in the halls, give him a high five, or challenge him to 20 pushups."
    
};
